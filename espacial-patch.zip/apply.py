import pathlib, shutil, sys

here = pathlib.Path(__file__).resolve().parent
root = pathlib.Path.cwd()
main = root / "app/src/main/java/com/music/bitchord"
audio = main / "playback/audio"
if not audio.exists():
    sys.exit("ERROR: ejecuta esto desde la raiz del repositorio de BitChord")

def rep(path, old, new, n=1):
    s = path.read_text(encoding="utf-8")
    c = s.count(old)
    if c != n:
        sys.exit(f"ERROR en {path.name}: esperaba {n} coincidencia(s) y hay {c} para:\n{old}")
    path.write_text(s.replace(old, new), encoding="utf-8")

# 1. archivos nuevos
shutil.copy(here / "files/BinauralEngine.kt", audio / "BinauralEngine.kt")
shutil.copy(here / "files/BinauralStore.kt", audio / "BinauralStore.kt")
shutil.copy(here / "files/EspacialActivity.kt", main / "EspacialActivity.kt")

# 2. PrecisionAudioSink
sink = audio / "PrecisionAudioSink.kt"
rep(sink,
"    private var outputByteBuffer: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())\n",
"""    // --- Espacial: render binaural opcional antes de la cadena DSP ---
    private var binaural: BinauralEngine? = null
    private var stereoBlock: AudioBlock = AudioBlock(channelCount = 2, capacityFrames = DEFAULT_CAPACITY_FRAMES)
    private var binauralActive: Boolean = false

    private var outputByteBuffer: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())
""")
rep(sink,
"""                val channelCount = format.channelCount

                // 1. Configure the Float32 DSP chain
                dspChain.configure(sampleRate, channelCount)
""",
"""                val channelCount = format.channelCount
                val useBinaural = BinauralParams.enabled &&
                    (channelCount == 2 || channelCount == 6 || channelCount == 8)
                binauralActive = useBinaural
                binaural = if (useBinaural) BinauralEngine(sampleRate, channelCount) else null
                val outFormat = if (useBinaural) format.buildUpon().setChannelCount(2).build() else format

                // 1. Configure the Float32 DSP chain
                dspChain.configure(sampleRate, if (useBinaural) 2 else channelCount)
""")
rep(sink,
"""                val floatFormat = format.buildUpon()
                    .setPcmEncoding(C.ENCODING_PCM_FLOAT)
                    .build()
                val pcm16Format = format.buildUpon()
                    .setPcmEncoding(C.ENCODING_PCM_16BIT)
                    .build()
""",
"""                val floatFormat = outFormat.buildUpon()
                    .setPcmEncoding(C.ENCODING_PCM_FLOAT)
                    .build()
                val pcm16Format = outFormat.buildUpon()
                    .setPcmEncoding(C.ENCODING_PCM_16BIT)
                    .build()
""")
rep(sink,
"""                val delegateFormat = format.buildUpon()
                    .setPcmEncoding(targetEncoding.toMedia3PcmEncoding())
                    .build()
""",
"""                val delegateFormat = outFormat.buildUpon()
                    .setPcmEncoding(targetEncoding.toMedia3PcmEncoding())
                    .build()
""")
rep(sink,
"setOutputChannelMapping(audioSinkConfig.outputChannelMapping)",
"setOutputChannelMapping(if (useBinaural) null else audioSinkConfig.outputChannelMapping)", n=2)
rep(sink,
"""        isPrecisionActive = false
        inputPcmEncoding = null
        targetOutputEncoding = null
        configuredSampleRate = 0
""",
"""        isPrecisionActive = false
        binauralActive = false
        binaural = null
        inputPcmEncoding = null
        targetOutputEncoding = null
        configuredSampleRate = 0
""")
rep(sink,
"""            dspChain.process(audioBlock)

            // Encode processed samples to target PCM output buffer (Float32 or PCM16)
            outputByteBuffer.clear()
            PcmBoundary.encode(
                sourceBlock = audioBlock,
""",
"""            val procBlock = if (binauralActive) {
                binaural?.let {
                    stereoBlock.reset(decodedFrames)
                    it.process(audioBlock.samples, decodedFrames, stereoBlock.samples)
                }
                stereoBlock
            } else {
                audioBlock
            }
            dspChain.process(procBlock)

            // Encode processed samples to target PCM output buffer (Float32 or PCM16)
            outputByteBuffer.clear()
            PcmBoundary.encode(
                sourceBlock = procBlock,
""")
rep(sink,
"""        if (isPrecisionActive) {
            dspChain.flush()
        }
        delegate.flush()
""",
"""        if (isPrecisionActive) {
            dspChain.flush()
            binaural?.reset()
        }
        delegate.flush()
""")

# 3. Application: cargar ajustes al arrancar
rep(main / "BitChordApplication.kt",
"""    override fun onCreate() {
        super.onCreate()
""",
"""    override fun onCreate() {
        super.onCreate()
        com.music.bitchord.playback.audio.BinauralStore.load(this)
""")

# 4. Manifest: segundo icono "Espacial"
rep(root / "app/src/main/AndroidManifest.xml",
"    </application>",
"""        <activity
            android:name=".EspacialActivity"
            android:exported="true"
            android:label="Espacial"
            android:theme="@android:style/Theme.Material.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>""")
print("Parche Espacial aplicado correctamente.")
