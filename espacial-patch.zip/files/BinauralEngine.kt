package com.music.bitchord.playback.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.tanh

/** Ajustes del motor espacial. Se leen en caliente; solo "enabled" se aplica al empezar cada canción. */
object BinauralParams {
    @Volatile var enabled = false
    @Volatile var ang = 30f
    @Volatile var rad = 8.75f
    @Volatile var fc = 1500f
    @Volatile var sh = -6f
    @Volatile var pf = 3500f
    @Volatile var pg = 3f
    @Volatile var rev = 18f
    @Volatile var room = 1f
    @Volatile var version = 0
    fun touch() { version++ }
}

/**
 * Convierte 2, 6 u 8 canales en estéreo binaural con bocinas virtuales:
 * retardo interaural, sombra de cabeza, resonancia del oído y reverb tipo Freeverb.
 * Entrada y salida: Float32 intercalado.
 */
class BinauralEngine(private val sr: Int, val n: Int) {
    private class Comb(size: Int) {
        val b = FloatArray(size); var i = 0; var s = 0f
        fun p(x: Float, fb: Float, d: Float): Float {
            val o = b[i]; s = o * (1 - d) + s * d; b[i] = x + s * fb
            if (++i >= b.size) i = 0
            return o
        }
    }

    private class Allpass(size: Int) {
        val b = FloatArray(size); var i = 0
        fun p(x: Float): Float {
            val o = b[i]; b[i] = x + o * 0.5f
            if (++i >= b.size) i = 0
            return o - x
        }
    }

    private val ring = Array(n) { FloatArray(128) }
    private var pos = 0
    private val rl = FloatArray(n)
    private val cl = FloatArray(n)
    private val az = FloatArray(n)
    private val dd = FloatArray(n)
    private val lfe = BooleanArray(n)
    private val ctr = BooleanArray(n)
    private val rear = BooleanArray(n)
    private var cA = 0f; private var cG = .5f; private var rA = 0f
    private var ver = -1
    private var b0 = 1f; private var b1 = 0f; private var b2 = 0f; private var a1 = 0f; private var a2 = 0f
    private var xl1 = 0f; private var xl2 = 0f; private var yl1 = 0f; private var yl2 = 0f
    private var xr1 = 0f; private var xr2 = 0f; private var yr1 = 0f; private var yr2 = 0f
    private var fb = .8f; private var wet = 0f
    private val tune = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val tuneAp = intArrayOf(556, 441, 341, 225)
    private val k = sr / 44100.0
    private val cmbL = Array(8) { Comb(max(8, (tune[it] * k).toInt())) }
    private val cmbR = Array(8) { Comb(max(8, ((tune[it] + 23) * k).toInt())) }
    private val apL = Array(4) { Allpass(max(8, (tuneAp[it] * k).toInt())) }
    private val apR = Array(4) { Allpass(max(8, ((tuneAp[it] + 23) * k).toInt())) }

    init {
        when (n) {
            1 -> ctr[0] = true
            6, 8 -> { ctr[2] = true; lfe[3] = true; rear[4] = true; rear[5] = true }
        }
    }

    /** Limpia retardos y colas de reverb (al buscar en la canción). */
    fun reset() {
        ring.forEach { it.fill(0f) }
        rl.fill(0f); cl.fill(0f)
        xl1 = 0f; xl2 = 0f; yl1 = 0f; yl2 = 0f; xr1 = 0f; xr2 = 0f; yr1 = 0f; yr2 = 0f
        cmbL.forEach { it.b.fill(0f); it.s = 0f }
        cmbR.forEach { it.b.fill(0f); it.s = 0f }
        apL.forEach { it.b.fill(0f) }
        apR.forEach { it.b.fill(0f) }
    }

    private fun refresh() {
        val v = BinauralParams.version
        if (v == ver) return
        ver = v
        val a = BinauralParams.ang
        when (n) {
            2 -> { az[0] = -a; az[1] = a }
            6 -> { az[0] = -a; az[1] = a; az[4] = -110f; az[5] = 110f }
            8 -> { az[0] = -a; az[1] = a; az[4] = -150f; az[5] = 150f; az[6] = -90f; az[7] = 90f }
        }
        for (c in 0 until n) {
            var t = Math.toRadians(abs(az[c]).toDouble())
            if (t > PI / 2) t = PI - t
            dd[c] = ((BinauralParams.rad / 100.0 / 343.0) * (t + sin(t)) * sr).toFloat()
        }
        cA = (1 - exp(-2 * PI * BinauralParams.fc / sr)).toFloat()
        rA = (1 - exp(-2 * PI * 5000.0 / sr)).toFloat()
        cG = 10f.pow(BinauralParams.sh / 20f)
        val aa = 10.0.pow(BinauralParams.pg / 40.0)
        val w0 = 2 * PI * BinauralParams.pf / sr
        val al = sin(w0) / (2 * 1.2)
        val a0 = 1 + al / aa
        b0 = ((1 + al * aa) / a0).toFloat(); b1 = (-2 * cos(w0) / a0).toFloat(); b2 = ((1 - al * aa) / a0).toFloat()
        a1 = (-2 * cos(w0) / a0).toFloat(); a2 = ((1 - al / aa) / a0).toFloat()
        fb = (0.7f + 0.28f * ((BinauralParams.room - 0.3f) / 2.2f)).coerceIn(0.7f, 0.98f)
        wet = BinauralParams.rev / 100f * 1.2f
    }

    private fun clip(x: Float): Float {
        val a = abs(x)
        return if (a < .9f) x else sign(x) * (.9f + .1f * tanh((a - .9f) / .1f))
    }

    /** [inp]: frames*n muestras intercaladas. [out]: frames*2 muestras. */
    fun process(inp: FloatArray, frames: Int, out: FloatArray) {
        refresh()
        val master = if (n >= 6) .55f else .8f
        for (f in 0 until frames) {
            pos = (pos + 1) and 127
            var l = 0f; var r = 0f; var send = 0f
            val base = f * n
            for (c in 0 until n) {
                var x = inp[base + c]
                if (lfe[c]) { l += x * .4f; r += x * .4f; continue }
                send += x
                if (ctr[c]) { l += x * .707f; r += x * .707f; continue }
                if (rear[c]) { rl[c] += rA * (x - rl[c]); x = rl[c] * .85f }
                val rg = ring[c]
                rg[pos] = x
                val t = pos - dd[c]
                val i0 = floor(t).toInt()
                val fr = t - i0
                val xc = rg[i0 and 127] * (1 - fr) + rg[(i0 + 1) and 127] * fr
                cl[c] += cA * (xc - cl[c])
                val con = cl[c] * cG
                if (az[c] > 0) { r += x; l += con } else { l += x; r += con }
            }
            val rin = send * .015f
            var oL = 0f; var oR = 0f
            for (j in 0 until 8) { oL += cmbL[j].p(rin, fb, .4f); oR += cmbR[j].p(rin, fb, .4f) }
            for (j in 0 until 4) { oL = apL[j].p(oL); oR = apR[j].p(oR) }
            l += oL * wet; r += oR * wet
            val yl = b0 * l + b1 * xl1 + b2 * xl2 - a1 * yl1 - a2 * yl2
            xl2 = xl1; xl1 = l; yl2 = yl1; yl1 = yl
            val yr = b0 * r + b1 * xr1 + b2 * xr2 - a1 * yr1 - a2 * yr2
            xr2 = xr1; xr1 = r; yr2 = yr1; yr1 = yr
            out[2 * f] = clip(yl * master)
            out[2 * f + 1] = clip(yr * master)
        }
    }
}
