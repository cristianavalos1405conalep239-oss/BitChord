package com.music.bitchord.playback.audio

import android.content.Context

/** Guarda y carga los ajustes del motor espacial. */
object BinauralStore {
    private const val PREFS = "espacial"
    private val keys = listOf("ang", "rad", "fc", "sh", "pf", "pg", "rev", "room")

    fun get(k: String): Float = when (k) {
        "ang" -> BinauralParams.ang; "rad" -> BinauralParams.rad; "fc" -> BinauralParams.fc
        "sh" -> BinauralParams.sh; "pf" -> BinauralParams.pf; "pg" -> BinauralParams.pg
        "rev" -> BinauralParams.rev; else -> BinauralParams.room
    }

    fun put(k: String, v: Float) {
        when (k) {
            "ang" -> BinauralParams.ang = v; "rad" -> BinauralParams.rad = v; "fc" -> BinauralParams.fc = v
            "sh" -> BinauralParams.sh = v; "pf" -> BinauralParams.pf = v; "pg" -> BinauralParams.pg = v
            "rev" -> BinauralParams.rev = v; else -> BinauralParams.room = v
        }
        BinauralParams.touch()
    }

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        BinauralParams.enabled = p.getBoolean("enabled", false)
        keys.forEach { put(it, p.getFloat(it, get(it))) }
    }

    fun save(ctx: Context) {
        val e = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        e.putBoolean("enabled", BinauralParams.enabled)
        keys.forEach { e.putFloat(it, get(it)) }
        e.apply()
    }
}
