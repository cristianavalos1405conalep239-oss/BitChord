package com.music.bitchord

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import com.music.bitchord.playback.audio.BinauralParams
import com.music.bitchord.playback.audio.BinauralStore

/** Pantalla de ajustes del sonido espacial. Se abre desde el segundo icono "Espacial". */
class EspacialActivity : Activity() {
    private val tx = Color.parseColor("#e6eef2")
    private val mu = Color.parseColor("#93a5b2")

    private class Cfg(val k: String, val l: String, val min: Float, val max: Float, val step: Float, val u: String)
    private val cfg = listOf(
        Cfg("ang", "Ángulo de las bocinas", 10f, 60f, 1f, "°"),
        Cfg("rad", "Tamaño de cabeza (radio)", 7f, 10f, .25f, " cm"),
        Cfg("fc", "Sombra de la cabeza", 600f, 4000f, 50f, " Hz"),
        Cfg("sh", "Cruce entre oídos", -14f, -1f, 1f, " dB"),
        Cfg("pf", "Resonancia del oído: frecuencia", 2000f, 9000f, 100f, " Hz"),
        Cfg("pg", "Resonancia del oído: nivel", -6f, 6f, .5f, " dB"),
        Cfg("rev", "Reverb", 0f, 60f, 1f, "%"),
        Cfg("room", "Tamaño de sala", .3f, 2.5f, .1f, " s"))
    private val presets = linkedMapOf(
        "Sutil" to mapOf("ang" to 20f, "rad" to 8.75f, "fc" to 1800f, "sh" to -8f, "pf" to 3500f, "pg" to 2f, "rev" to 8f, "room" to .6f),
        "Natural" to mapOf("ang" to 30f, "rad" to 8.75f, "fc" to 1500f, "sh" to -6f, "pf" to 3500f, "pg" to 3f, "rev" to 18f, "room" to 1f),
        "Amplio" to mapOf("ang" to 45f, "rad" to 9f, "fc" to 1200f, "sh" to -4f, "pf" to 4000f, "pg" to 3f, "rev" to 28f, "room" to 1.5f))
    private val bars = HashMap<String, SeekBar>()

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun label(t: String, size: Float = 15f, c: Int = tx) =
        TextView(this).apply { text = t; textSize = size; setTextColor(c); setPadding(0, dp(4), 0, dp(4)) }
    private fun fv(x: Float) = if (x % 1f == 0f) x.toInt().toString() else "%.2f".format(x)
    private fun setBar(k: String) {
        val c = cfg.first { it.k == k }
        bars[k]?.progress = Math.round((BinauralStore.get(k) - c.min) / c.step)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        BinauralStore.load(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(32)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0f1a22")); fitsSystemWindows = true; addView(root) })
        root.addView(label("Espacial a tu medida", 26f))
        root.addView(label("Bocinas virtuales para música estéreo y Atmos 5.1. Los ajustes suenan al instante; el interruptor se aplica al empezar la siguiente canción.", 13f, mu))
        root.addView(Switch(this).apply {
            text = "Sonido espacial activado"; isChecked = BinauralParams.enabled; setTextColor(tx); setPadding(0, dp(12), 0, dp(8))
            setOnCheckedChangeListener { _, on -> BinauralParams.enabled = on; BinauralStore.save(this@EspacialActivity) }
        })
        root.addView(label("Si lo usas, apaga el audio espacial de BitChord para no sumar efectos.", 12f, mu))
        val pr = LinearLayout(this)
        presets.forEach { (name, vals) ->
            pr.addView(Button(this).apply {
                text = name; isAllCaps = false
                setOnClickListener { vals.forEach { (k, v) -> BinauralStore.put(k, v); setBar(k) }; BinauralStore.save(this@EspacialActivity) }
            })
        }
        root.addView(pr)
        cfg.forEach { c ->
            val lb = label("", 14f)
            val sb = SeekBar(this).apply { max = Math.round((c.max - c.min) / c.step) }
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) {
                    val x = c.min + p * c.step
                    if (user) BinauralStore.put(c.k, x)
                    lb.text = c.l + ": " + fv(x) + c.u
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { BinauralStore.save(this@EspacialActivity) }
            })
            bars[c.k] = sb
            root.addView(lb); root.addView(sb)
            setBar(c.k)
        }
    }
}
